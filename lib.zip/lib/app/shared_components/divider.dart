
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

Widget Divider() {
  return Container(
    height: 1.h,
    width: 1.sw,
    color: Colors.grey[300],
  );
}