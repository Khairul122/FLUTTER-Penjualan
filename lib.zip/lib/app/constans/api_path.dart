part of app_constants;

/// all endpoint api
class ApiPath {
  // Example :
  // static const _BASE_URL = "https://api.nitrogia.com";
  // static const product = "$_BASE_URL/product";
}
