library app_mixins;

part 'navigation_mixin.dart';
part 'validation_input_mixin.dart';
