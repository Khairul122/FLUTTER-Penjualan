part of app_helpers;

class StringHelper {}
