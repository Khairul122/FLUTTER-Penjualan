part of app_helpers;

// this file focused on enum data

// Example:
// enum userType{admin, member}