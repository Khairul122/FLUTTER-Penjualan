part of ui_utils;

// contains all dialog templates
class AppDialog {}
