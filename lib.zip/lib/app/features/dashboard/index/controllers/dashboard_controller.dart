part of dashboard;

class DashboardController extends GetxController {
  PersistentTabController persistentTab =
      PersistentTabController(initialIndex: 0);
}
