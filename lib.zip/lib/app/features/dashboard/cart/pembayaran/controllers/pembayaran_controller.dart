import 'package:get/get.dart';
import 'package:marketplace/app/utils/services/rest_api_services.dart';
import 'package:hive/hive.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class PembayaranController extends GetxController {
  final productService = ProductService();
  var userData = {}.obs;
  var alamat = ''.obs;
  var ongkir = 0.obs;

  GetItemPembayaran() => productService.getListPembayaran();

  @override
  void onInit() {
    super.onInit();
    fetchUserData();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  void fetchUserData() async {
    var box = Hive.box('userBox');
    var data = box.get('user');
    userData.value = data;

    if (data != null) {
      var idAlamat = data['id_alamat'];
      var url = Uri.parse('http://10.0.2.2/backend-penjualan/AlamatAPI.php?id_alamat=$idAlamat');
      var response = await http.get(url);

      if (response.statusCode == 200) {
        var jsonData = json.decode(response.body);
        alamat.value = jsonData['alamat'];
        ongkir.value = jsonData['ongkir'];
      } else {
        print("Gagal mengambil data alamat dari REST API");
      }
    }
  }
}
