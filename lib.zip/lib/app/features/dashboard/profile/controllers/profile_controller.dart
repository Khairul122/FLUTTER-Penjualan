part of profile;

class ProfileController extends GetxController {
  //TODO: Implement ProfileController

  final count = 0.obs;

  TextEditingController namaPengguna = TextEditingController();
  TextEditingController email = TextEditingController();
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  void increment() => count.value++;
}
