part of explore;

class ExploreController extends GetxController {}
